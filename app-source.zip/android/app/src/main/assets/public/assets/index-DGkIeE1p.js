const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-dsjSRps0.js","./index-Bx2kzUt0.js","./index--fkbJPfH.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Bx2kzUt0.js";const _=r("Share",{web:()=>t(()=>import("./web-dsjSRps0.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
