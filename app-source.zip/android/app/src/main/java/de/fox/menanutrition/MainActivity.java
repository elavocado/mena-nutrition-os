package de.fox.menanutrition;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
