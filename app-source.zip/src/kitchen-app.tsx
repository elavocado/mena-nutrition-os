"use client";

import {useCallback,useEffect,useMemo,useState} from "react";
import {Bell,BellOff,Check,ChevronRight,Clock,Cloud,Copy,FileImage,Globe2,Heart,House,Loader2,Minus,Plus,Refrigerator,RotateCcw,ScanLine,ShieldCheck,ShoppingBasket,Shuffle,Sparkles,Timer,UtensilsCrossed,X,Zap} from "lucide-react";
import recipesData from "./recipes.json";
import productsData from "./products.json";
import {parseReceipt,ScanCandidate} from "./receipt";
import {requestOffline,exportBackup,restoreBackup} from "./offline-data";
import {Capacitor} from "@capacitor/core";

type Lang="en"|"ar";
type View="today"|"meals"|"kitchen"|"shopping";
type Section="breakfast"|"snack"|"lunch"|"dinner"|"fast";
type Mood="rush"|"hungry"|"stock"|"surprise";
type Area="fridge"|"freezer"|"pantry";
type Recipe={id:string;categories:string[];emoji:string;device:string;minutes:number;units:Record<string,number>;name:Record<Lang,string>;sub:Record<Lang,string>;steps:Record<Lang,string[]>;batch?:boolean;leftover?:boolean};
type Item={code:string;name:string;quantity:number;unit:string;area:Area;expiresAt:string|null;updatedAt:string};
type Preferences={enabled:boolean;times:string[]};
type MealEvent={recipeId:string;event:string;createdAt:string};
type ApiState={items:Item[];counts:Record<string,number>;checked:Record<string,boolean>;imports:Array<{fingerprint:string;productCount:number;createdAt:string}>;preferences:Preferences;history:MealEvent[]};
type Product={en:string;ar:string};
const recipes=recipesData as Recipe[];
const labels=productsData as Record<string,Product>;
const catalog: Array<{code:string;name:string;area:Area;unit:string;quantity:number}>=[
  {code:"salmon",name:"Salmon fillet / Lachs",area:"freezer",unit:"fillet",quantity:1},
  {code:"chicken",name:"Chicken portion / Hähnchenbrust",area:"freezer",unit:"piece",quantity:1},
  {code:"beef",name:"Lean mince 400g",area:"fridge",unit:"400g pack",quantity:1},
  {code:"tuna",name:"Tuna / Thunfisch",area:"pantry",unit:"can",quantity:1},
  {code:"eggs",name:"Eggs / Eier",area:"fridge",unit:"egg",quantity:6},
  {code:"rice",name:"Rice / Reis",area:"pantry",unit:"100g scoop",quantity:10},
  {code:"pasta",name:"Combino Pasta 500g",area:"pantry",unit:"100g portion",quantity:5},
  {code:"potato",name:"Ready wedges 750g",area:"freezer",unit:"750g bag",quantity:1},
  {code:"veg",name:"Buttergemüse 300g",area:"freezer",unit:"300g carton",quantity:1},
  {code:"banana",name:"Bananas / Bananen",area:"pantry",unit:"banana",quantity:3},
  {code:"yogurt",name:"Lactose-free yogurt 500g",area:"fridge",unit:"500g tub",quantity:1},
  {code:"cheese",name:"Suitable cheese slices",area:"fridge",unit:"slice",quantity:6},
  {code:"oats",name:"Oats / Haferflocken",area:"pantry",unit:"tbsp",quantity:20}
];
const easyWeek:Record<string,number>={b_yogurt:2,b_overnight:1,b_eggs_cheese:2,b_egg_potato:2,s_banana:7,s_yogurt:3,s_eggs:4,m_salmon_rice:1,m_salmon_pasta:1,m_chicken_rice:1,m_chicken_pasta:1,m_tuna_rice:1,m_beef_wedges:1,m_chicken_wedges:1};
const fmt=(x:number)=>Number.isInteger(x)?String(x):String(Math.round(x*100)/100);
const slug=(s:string)=>{
  const ascii=s.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"").slice(0,65);
  return ascii||Array.from(s).map(ch=>ch.codePointAt(0)!.toString(16)).join("_").slice(0,65);
};
const locationEmoji:Record<Area,string>={fridge:"🧊",freezer:"❄️",pantry:"📦"};
const defaultTimes=["12:30","16:30","19:30"];
const expiryDistance=(date:string|null)=>date?new Date(date+"T23:59:59").getTime()-Date.now():null;
const beforeExpiry=(date:string|null)=>{const distance=expiryDistance(date);return distance!==null&&distance>=0&&distance<3*86400000;};
const datePast=(date:string|null)=>{const distance=expiryDistance(date);return distance!==null&&distance<0;};

function getSuggestions(mood:Mood,stock:Record<string,number>,items:Item[],history:MealEvent[],shuffle:number,reset:boolean){
  const leftovers=items.filter(i=>i.code.startsWith("leftover:")&&i.quantity>=1);
  const recent=history.filter(x=>x.event==="cooked").slice(0,5).map(x=>x.recipeId);
  const pool=recipes.filter(r=>!r.leftover||leftovers.length>0);
  const ranked=pool.map(recipe=>{
    const needs=Object.entries(recipe.units);
    const lacking=recipe.leftover?0:needs.filter(([code,quantity])=>(stock[code]||0)<quantity).length;
    const available=recipe.leftover?leftovers.length>0:lacking===0;
    const expiring=needs.filter(([code])=>items.some(i=>i.code===code&&i.quantity>0&&beforeExpiry(i.expiresAt))).length;
    const newness=recent.includes(recipe.id)?-(6-recent.indexOf(recipe.id))*5:0;
    const main=recipe.categories.includes("lunch")||recipe.categories.includes("dinner");
    const mainScore=main?12:0;
    let score=available?100:Math.max(0,35-lacking*16);
    if(mood==="rush"||reset)score+=Math.max(0,28-recipe.minutes*2)+(recipe.categories.includes("fast")?24:0);
    if(mood==="hungry"&&!reset)score+=mainScore*2+(recipe.batch?18:0);
    if(mood==="stock"&&!reset)score+=expiring*30+(recipe.leftover?60:0);
    if(mood==="surprise"&&!reset)score+=mainScore+((recipes.indexOf(recipe)*37+shuffle*61)%41);
    score+=newness+((recipes.indexOf(recipe)*31+shuffle*17)%11);
    return {recipe,available,lacking,expiring,score};
  });
  ranked.sort((a,b)=>b.score-a.score||a.recipe.minutes-b.recipe.minutes);
  return ranked.slice(0,3);
}

declare global {
  interface Window {Tesseract?:{createWorker:(lang:string)=>Promise<{recognize:(file:File)=>Promise<{data:{text:string}}>;terminate:()=>Promise<void>}>};}
}

async function loadOcr(){
  if(window.Tesseract)return window.Tesseract;
  await new Promise<void>((resolve,reject)=>{
    const script=document.createElement("script");
    script.src="https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js";
    script.onload=()=>resolve();script.onerror=()=>reject(new Error("OCR library could not load"));
    document.head.appendChild(script);
  });
  if(!window.Tesseract)throw new Error("OCR library unavailable");
  return window.Tesseract;
}
async function fingerprint(source:string|File){
  // Local HTTP preview is not a secure context; production HTTPS uses SHA-256.
  if(typeof crypto==="undefined"||!crypto.subtle)return "";
  const bytes=typeof source==="string"?new TextEncoder().encode(source):await source.arrayBuffer();
  const buffer=await crypto.subtle.digest("SHA-256",bytes);
  return Array.from(new Uint8Array(buffer)).map(x=>x.toString(16).padStart(2,"0")).join("");
}
async function requestApi(body?:object):Promise<any>{
  return requestOffline(body as {action:string}|undefined);
}

export default function KitchenApp({signedIn,displayName,signInPath}:{signedIn:boolean;displayName:string;signInPath:string}){
  const [lang,setLang]=useState<Lang>("en");
  const [view,setView]=useState<View>("today");
  const [section,setSection]=useState<Section>("lunch");
  const [mood,setMood]=useState<Mood>("stock");
  const [shuffle,setShuffle]=useState(0);
  const [resetMode,setResetMode]=useState(false);
  const [items,setItems]=useState<Item[]>([]);
  const [counts,setCounts]=useState<Record<string,number>>({});
  const [checked,setChecked]=useState<Record<string,boolean>>({});
  const [imports,setImports]=useState<ApiState["imports"]>([]);
  const [preferences,setPreferences]=useState<Preferences>({enabled:false,times:defaultTimes});
  const [history,setHistory]=useState<MealEvent[]>([]);
  const [activeReminder,setActiveReminder]=useState<number|null>(null);
  const [loading,setLoading]=useState(signedIn);
  const [saving,setSaving]=useState(false);
  const [notice,setNotice]=useState("");
  const [selectedRecipe,setSelectedRecipe]=useState<Recipe|null>(null);
  const [quickCode,setQuickCode]=useState("salmon");
  const [quickName,setQuickName]=useState("");
  const [quickQty,setQuickQty]=useState(1);
  const [quickArea,setQuickArea]=useState<Area>("freezer");
  const [expiryCode,setExpiryCode]=useState("");
  const [expiryDate,setExpiryDate]=useState("");
  const [receiptOpen,setReceiptOpen]=useState(false);
  const [receiptText,setReceiptText]=useState("");
  const [scanStatus,setScanStatus]=useState("");
  const [scanCandidates,setScanCandidates]=useState<ScanCandidate[]>([]);
  const [scanHash,setScanHash]=useState("");
  const [scanMode,setScanMode]=useState<"input"|"review">("input");
  const t=(en:string,ar:string)=>lang==="ar"?ar:en;

  const reload=useCallback(async()=>{
    if(!signedIn)return;
    const state=await requestApi() as ApiState;
    setItems(state.items);setCounts(state.counts);setChecked(state.checked);setImports(state.imports);
    setPreferences({enabled:!!state.preferences?.enabled,times:Array.isArray(state.preferences?.times)&&state.preferences.times.length===3?state.preferences.times:defaultTimes});
    setHistory(state.history||[]);
  },[signedIn]);
  useEffect(()=>{
    try{const stored=localStorage.getItem("mena-language");if(stored==="ar")setLang("ar");}catch{}
    const hash=window.location.hash;
    if(hash.includes("shopping"))setView("shopping");
    if(hash.includes("kitchen"))setView("kitchen");
    if(hash.includes("meals"))setView("meals");
    if(hash.includes("fast")){setView("today");setMood("rush");}
  },[]);
  useEffect(()=>{
    if(!preferences.enabled||!signedIn){setActiveReminder(null);return;}
    const tick=()=>{
      const now=new Date();const minutes=now.getHours()*60+now.getMinutes();
      const day=[now.getFullYear(),String(now.getMonth()+1).padStart(2,"0"),String(now.getDate()).padStart(2,"0")].join("-");
      const due=preferences.times.findIndex((time,i)=>{
        const [h,m]=time.split(":").map(Number);const start=h*60+m;
        try{return minutes>=start&&minutes<start+75&&!localStorage.getItem(`mena-reminder-${day}-${i}`);}catch{return false;}
      });
      setActiveReminder(due>=0?due:null);
    };
    tick();const timer=setInterval(tick,60000);return()=>clearInterval(timer);
  },[preferences,signedIn]);
  useEffect(()=>{
    if(!signedIn)return;
    reload().catch(e=>setNotice(e.message)).finally(()=>setLoading(false));
  },[signedIn,reload]);
  const setLanguage=(next:Lang)=>{setLang(next);try{localStorage.setItem("mena-language",next);}catch{}};
  const changeView=(next:View)=>{
    setView(next);
    window.history.replaceState(null,"","#"+next);
    window.scrollTo({top:0,behavior:"instant"});
  };
  const doSave=async(body:object,success:string)=>{
    if(!signedIn){setNotice(t("Sign in to save your personal kitchen","سجّل دخول علشان تحفظ مطبخك"));return false;}
    setSaving(true);
    try{await requestApi(body);await reload();setNotice(success);return true;}
    catch(e){setNotice(e instanceof Error?e.message:"Save failed");return false;}
    finally{setSaving(false);}
  };
  const savePlan=async(next:Record<string,number>,nextChecked=checked)=>{
    setCounts(next);setChecked(nextChecked);
    const ok=await doSave({action:"plan",counts:next,checked:nextChecked},t("Saved on your phone ✓","اتحفظ على موبايلك ✓"));
    if(!ok)await reload().catch(()=>{});
  };
  const planned=useMemo(()=>{
    const sums:Record<string,number>={};
    for(const recipe of recipes){
      const n=counts[recipe.id]||0;
      for(const [key,value] of Object.entries(recipe.units))sums[key]=(sums[key]||0)+n*value;
    }
    return sums;
  },[counts]);
  const stock=useMemo(()=>Object.fromEntries(items.map(i=>[i.code,i.quantity])) as Record<string,number>,[items]);
  const suggestionStock=useMemo(()=>Object.fromEntries(items.map(i=>[i.code,datePast(i.expiresAt)?0:i.quantity])) as Record<string,number>,[items]);
  const suggestions=useMemo(()=>getSuggestions(mood,suggestionStock,items,history,shuffle,resetMode),[mood,suggestionStock,items,history,shuffle,resetMode]);
  const leftovers=items.filter(i=>i.code.startsWith("leftover:")&&i.quantity>=1);
  const useSoon=items.filter(i=>i.quantity>0&&!i.code.startsWith("leftover:")&&beforeExpiry(i.expiresAt));
  const pastDate=items.filter(i=>i.quantity>0&&datePast(i.expiresAt));
  const shopping=useMemo(()=>catalog.map(p=>({...p,needed:planned[p.code]||0,owned:stock[p.code]||0,buy:Math.max(0,(planned[p.code]||0)-(stock[p.code]||0))})).filter(p=>p.needed>0),[planned,stock]);
  const missing=shopping.filter(p=>p.buy>0);
  const batches=recipes.filter(r=>r.batch).reduce((a,r)=>a+(counts[r.id]||0),0);
  const filteredRecipes=recipes.filter(r=>r.categories.includes(section));
  const areaCount=(area:Area)=>items.filter(i=>i.area===area&&i.quantity>0).length;
  const unitText=(code:string,n:number)=>fmt(n)+" "+(labels[code]?.[lang]||code);

  const addQuick=async()=>{
    const known=catalog.find(x=>x.code===quickCode);
    const name=known?.name||quickName.trim();
    const code=known?.code||"other:"+slug(name);
    if(!name||!Number.isFinite(quickQty)||quickQty<=0){setNotice(t("Enter a valid item and amount","اكتب منتج وكمية صحيحة"));return;}
    const ok=await doSave({action:"bulk",items:[{code,name,quantity:quickQty,unit:known?.unit||"piece",area:quickArea}]},t("Added to My Kitchen ✓","اتضاف لمطبخك ✓"));
    if(ok){setQuickName("");setQuickQty(1);}
  };
  const adjust=async(i:Item,delta:number)=>{
    await doSave({action:"adjust",code:i.code,delta},t("Stock updated ✓","المخزون اتحدّث ✓"));
  };
  const chooseQuick=(code:string)=>{
    const selected=catalog.find(p=>p.code===code);
    setQuickCode(code);if(selected){setQuickQty(selected.quantity);setQuickArea(selected.area);}
  };
  const importText=async(text:string,file?:File)=>{
    const candidates=parseReceipt(text);setReceiptText(text);setScanCandidates(candidates);
    setScanHash(await fingerprint(file||text));
    setScanMode("review");setScanStatus("");
    if(!candidates.length)setNotice(t("No clear product rows found. Try another image or edit the text.","مش لاقي أسطر منتجات واضحة. جرّب صورة أو نص أوضح."));
  };
  const readReceipt=async(file:File)=>{
    if(!file.type.startsWith("image/")){setNotice(t("For now, upload a JPG/PNG screenshot of your Lidl receipt.","دلوقتي ارفع صورة JPG/PNG للبون من Lidl Plus."));return;}
    setScanStatus(t("Reading image privately in your browser…","بقرأ الصورة على جهازك من غير رفعها للسيرفر…"));
    try{
      const ocr=await loadOcr();
      const worker=await ocr.createWorker("deu");
      let content="";
      try{content=(await worker.recognize(file)).data.text;}
      finally{await worker.terminate();}
      await importText(content,file);
    }catch(e){setScanStatus("");setNotice(t("OCR unavailable. Paste receipt text or use Quick Add.","قراءة الصورة مش متاحة دلوقتي. الصق النص أو استخدم الإضافة اليدوية."));}
  };
  const updateCandidate=(id:string,patch:Partial<ScanCandidate>)=>setScanCandidates(v=>v.map(c=>c.id===id?{...c,...patch}:c));
  const confirmReceipt=async()=>{
    const selected=scanCandidates.filter(x=>x.include&&x.quantity>0&&x.name.trim()).map(({code,name,quantity,unit,area})=>({code,name,quantity,unit,area}));
    if(!selected.length){setNotice(t("Select at least one item to import","اختار منتج واحد على الأقل"));return;}
    const ok=await doSave({action:"bulk",items:selected,fingerprint:scanHash},t("Receipt imported and saved ✓","البون اتحفظ والمنتجات اتضافت ✓"));
    if(ok){setReceiptOpen(false);setScanMode("input");setScanCandidates([]);setReceiptText("");}
  };
  const markCooked=async(recipe:Recipe)=>{
    if(!confirm(t("Mark this as cooked? Ingredients will be deducted from your saved stock.","تأكيد إنك طبخت الوجبة؟ هنخصم المكونات من مخزونك.")))return;
    const ok=await doSave({action:"cook",recipeId:recipe.id},t("Cooked! Stock updated and leftovers saved when applicable ✓","اتطبخت! المخزون اتحدّث والبواقي اتحفظت ✓"));
    if(ok)setSelectedRecipe(null);
  };
  const eatLeftover=async(code:string)=>{
    const ok=await doSave({action:"eat_leftover",code},t("Enjoy your leftover! Saved one serving less ✓","بالهنا يا فوكس! اتخصمت وجبة من البواقي ✓"));
    if(ok)setSelectedRecipe(null);
  };
  const savePreferences=async()=>await doSave({action:"preferences",enabled:preferences.enabled,times:preferences.times},t("Reminder preferences saved ✓","تفضيلات التذكير اتحفظت ✓"));
  const dismissReminder=()=>{
    if(activeReminder===null)return;
    const now=new Date();const day=[now.getFullYear(),String(now.getMonth()+1).padStart(2,"0"),String(now.getDate()).padStart(2,"0")].join("-");
    try{localStorage.setItem(`mena-reminder-${day}-${activeReminder}`,"1");}catch{}
    setActiveReminder(null);
  };
  const startReset=()=>{setResetMode(true);setMood("rush");changeView("today");};
  const addBought=async(p:typeof catalog[number]&{buy:number})=>{
    await doSave({action:"bulk",items:[{code:p.code,name:p.name,unit:p.unit,quantity:p.buy,area:p.area}]},t("Added to My Kitchen ✓","اتضاف للمخزون ✓"));
  };
  const copyShopping=async()=>{
    const lines=missing.map(x=>"☐ "+x.name+": "+fmt(x.buy)+" "+x.unit);
    try{await navigator.clipboard.writeText(lines.join("\n"));setNotice(t("Shopping list copied ✓","قايمة المشتريات اتنسخت ✓"));}
    catch{setNotice(t("Copy blocked by browser","المتصفح منع النسخ"));}
  };
  const shareBackup=async()=>{
    try{
      const content=await exportBackup();
      const filename=`mena-nutrition-backup-${new Date().toISOString().slice(0,10)}.json`;
      if(Capacitor.isNativePlatform()){
        const {Filesystem,Directory,Encoding}=await import("@capacitor/filesystem");
        const {Share}=await import("@capacitor/share");
        await Filesystem.writeFile({path:filename,data:content,directory:Directory.Cache,encoding:Encoding.UTF8});
        const file=await Filesystem.getUri({path:filename,directory:Directory.Cache});
        await Share.share({title:"Mena OS backup",url:file.uri,dialogTitle:t("Save to Drive or another safe place","احفظه على Drive أو مكان آمن")});
      }else{
        const url=URL.createObjectURL(new Blob([content],{type:"application/json"}));
        const a=document.createElement("a");a.href=url;a.download=filename;a.click();
        setTimeout(()=>URL.revokeObjectURL(url),1000);
      }
      setNotice(t("Backup ready. Choose a safe location to keep it.","النسخة الاحتياطية جاهزة. اختار مكان آمن تحفظها فيه."));
    }catch(e){setNotice(e instanceof Error?e.message:"Backup failed");}
  };
  const importBackup=async(file:File)=>{
    if(!window.confirm(t("Replace the current kitchen with this backup?", "هنستبدل بيانات المطبخ الحالية بالنسخة الاحتياطية دي. متأكد؟")))return;
    try{await restoreBackup(await file.text());await reload();setNotice(t("Kitchen restored successfully ✓","رجّعنا بيانات مطبخك بنجاح ✓"));}
    catch(e){setNotice(e instanceof Error?e.message:"Invalid backup file");}
  };

  return <div className="nutrition-os" dir={lang==="ar"?"rtl":"ltr"}>
    <div className="app-layout">
      <aside className="app-sidebar">
        <div className="brand-lockup"><div className="brand-mark">M<span>.</span></div><div><strong>MENA NUTRITION</strong><small>YOUR FOOD. YOUR RULES.</small></div></div>
        <p className="sidebar-eyebrow">{t("YOUR KITCHEN WORKSPACE","مساحة مطبخك")}</p>
        <nav className="primary-nav">
          <button className={view==="today"?"chosen":""} onClick={()=>changeView("today")}><House size={19}/>{t("Today","النهارده")}<ChevronRight size={15} className="push-icon"/></button>
          <button className={view==="meals"?"chosen":""} onClick={()=>changeView("meals")}><UtensilsCrossed size={19}/>{t("Meal Library","مكتبة الوجبات")}<ChevronRight size={15} className="push-icon"/></button>
          <button className={view==="kitchen"?"chosen":""} onClick={()=>changeView("kitchen")}><Refrigerator size={19}/>{t("My Kitchen","مطبخي")}<ChevronRight size={15} className="push-icon"/></button>
          <button className={view==="shopping"?"chosen":""} onClick={()=>changeView("shopping")}><ShoppingBasket size={19}/>{t("Lidl Shopping List","مشتريات Lidl")}<ChevronRight size={15} className="push-icon"/></button>
        </nav>
        <div className="sidebar-info"><div className="sidebar-info-icon"><ShieldCheck size={20}/></div><strong>{t("Private & offline","خاص وبيشتغل أوفلاين")}</strong><p>{t("Your meals and stock are stored on this phone. Save a backup so you can recover them if you replace it.","وجباتك ومخزونك على الموبايل ده. اعمل Backup علشان لو غيرت الجهاز تقدر ترجعهم.")}</p></div>
        <div className="sidebar-bottom"><span className="online-dot"/>{t("Local SQLite storage","SQLite محلي على الجهاز")}</div>
      </aside>

      <main className="main-panel">
        <header className="topbar">
          <div className="breadcrumbs">MENA OS <span>/</span> {view==="today"?t("Today","النهارده"):view==="meals"?t("Meal Library","الوجبات"):view==="kitchen"?t("My Kitchen","مطبخي"):t("Lidl List","مشتريات Lidl")}</div>
          <div className="mobile-header"><span className="mobile-app-logo">M<span>.</span></span><div><strong>Mena OS</strong><small>{t("Your food, made easy","أكلك ببساطة")}</small></div></div>
          <div className="topbar-actions">
            <button className="lang-switch" onClick={()=>setLanguage(lang==="en"?"ar":"en")}><Globe2 size={15}/>{lang==="en"?"عربي":"EN"}</button>
            <div className="avatar">M</div>
          </div>
        </header>
        <div className="main-content">
          {!!notice&&<div className="notice" role="status"><Sparkles size={16}/><span>{notice}</span><button aria-label="Dismiss" onClick={()=>setNotice("")}><X size={15}/></button></div>}
          {activeReminder!==null&&<div className="gentle-alert" role="status"><Bell size={19}/><div><strong>{t("Hey Mena, a little food break? 💚","يا مينا، إيه رأيك في بريك أكل صغير؟ 💚")}</strong><p>{t("No pressure. Your next meal is always a fresh start.","براحتك خالص. كل وجبة فرصة جديدة.")}</p></div><button className="subtle-button" onClick={()=>{dismissReminder();setMood("rush");changeView("today");}}>{t("Find something easy","هات حاجة سهلة")}</button><button className="ghost-icon" onClick={dismissReminder} aria-label={t("Dismiss for today","إخفاء لليوم")}><X size={17}/></button></div>}
          <div className="page-title-row">
            <div><div className="eyebrow"><span className="eyebrow-dot"/> PERSONAL FOOD OS · V5</div><h1>{view==="today"?t(`Hey ${displayName.split(" ")[0]||"Mena"}, let's make food easy 👋`,`أهلاً يا ${displayName.split(" ")[0]||"مينا"}، نسهّل الأكل النهارده 👋`):view==="meals"?t("Eat your way, Mena 👋","اختار براحتك يا مينا 👋"):view==="kitchen"?t("Your kitchen, under control. 🧊","مطبخك تحت السيطرة 🧊"):t("Buy what you actually need. 🛒","اشتري اللي ناقصك بس 🛒")}</h1>
              <p className="page-sub">{view==="today"?t("No catching up. No perfect days. Just something good to eat next.","مفيش أيام لازم تعوضها ولا يوم مثالي. بس نختار الوجبة الجاية."):view==="meals"?t("No calendar. Pick what sounds good, then cook once and eat twice.","مفيش جدول إجباري. اختار اللي تحبه واطبخ مرة وكل مرتين."):view==="kitchen"?t("Import a Lidl receipt or add your usual foods in seconds. Everything saves privately on your phone.","استورد بون Lidl أو ضيف حاجاتك المعتادة بسرعة. كله بيتحفظ على موبايلك."):t("Your weekly Lidl list automatically considers what is already in your kitchen.","قايمة Lidl الأسبوعية بتراعي الموجود عندك في البيت.")}</p>
            </div>
            <div className="title-actions">{view==="kitchen"&&<button className="primary-button" onClick={()=>{setReceiptOpen(true);setScanMode("input");}}><ScanLine size={17}/>{t("Import receipt","استيراد بون")}</button>}{view==="meals"&&<button className="primary-button" onClick={()=>changeView("shopping")}><ShoppingBasket size={17}/>{t("Weekly Lidl list","مشتريات الأسبوع")}</button>}</div>
          </div>
          <section className="stats-grid">
            <div className="stat-panel"><div className="stat-icon green">🧊</div><div><span>{t("Food types in stock","أنواع أكل موجودة")}</span><strong>{items.filter(i=>i.quantity>0).length}</strong></div></div>
            <div className="stat-panel"><div className="stat-icon peach">🥘</div><div><span>{t("Selected cooking batches","طبخات الأسبوع")}</span><strong>{batches}</strong></div></div>
            <div className="stat-panel"><div className="stat-icon lavender">🛒</div><div><span>{t("Items to buy","منتجات ناقصة")}</span><strong>{missing.length}</strong></div></div>
          </section>

          {view==="today"&&<section className="content-section today-space">
            <div className="today-hero"><div className="today-hero-copy"><span className="hero-kicker"><Sparkles size={15}/>{t("YOUR EASY NEXT STEP","خطوتك السهلة الجاية")}</span><h2>{resetMode?t("We just start with one meal. That's enough.","نبدأ بوجبة واحدة. وده كفاية."):t("What should I eat right now?","آكل إيه دلوقتي؟")}</h2><p>{resetMode?t("No missed-day maths. No food rules to make up for. Just pick what's doable.","مفيش حساب لأيام فاتت ولا تعويض. اختار بس الأسهل ليك دلوقتي."):t("Three ideas, based on your kitchen and what you've cooked recently.","٣ اقتراحات من الموجود عندك، مع مراعاة اللي طبخته قريب.")}</p></div><div className="hero-illustration" aria-hidden="true">🍽️<span>✨</span></div></div>
            <div className="mood-grid">
              {([{id:"rush",emoji:"⚡",en:"I'm in a rush",ar:"أنا مزنوق"},{id:"hungry",emoji:"🍚",en:"I'm hungry",ar:"أنا جعان"},{id:"stock",emoji:"🧊",en:"Use my fridge",ar:"من الموجود عندي"},{id:"surprise",emoji:"🎲",en:"Surprise me",ar:"فاجئني"}] as const).map(x=><button key={x.id} className={"mood-button "+(mood===x.id?"active":"")} onClick={()=>{setMood(x.id);setResetMode(false);if(x.id==="surprise")setShuffle(v=>v+1);}}><span className="mood-emoji">{x.emoji}</span><strong>{t(x.en,x.ar)}</strong>{mood===x.id&&<Check size={15}/>}</button>)}
            </div>
            <div className="section-heading today-heading"><div><span className="section-kicker">{t("PICK ONE, THAT'S ALL","اختار واحدة وخلاص")}</span><h2>{t("Three easy choices for you","٣ اختيارات سهلة ليك")}</h2></div><button className="subtle-button" onClick={()=>setShuffle(v=>v+1)}><Shuffle size={15}/>{t("Other ideas","غيّرهم")}</button></div>
            <div className="suggestion-grid">{suggestions.map(({recipe,available,lacking,expiring})=><article className="suggestion-card" key={recipe.id}><div className="suggestion-visual"><span>{recipe.emoji}</span><span className={"availability "+(available?"ready":"missing")}>{available?t("✓ In your kitchen","✓ موجود عندك"):t(`Needs ${lacking||1} item${lacking===1?"":"s"}`,lacking===1?"ناقص مكوّن واحد":`ناقص ${lacking||1} مكونات`)}</span></div><div className="suggestion-copy"><span className="suggestion-time"><Timer size={13}/>{recipe.minutes} {t("min","دقيقة")}{recipe.batch?" · "+t("2 servings","وجبتين"):""}</span><h3>{recipe.name[lang]}</h3><p>{recipe.sub[lang]}</p>{expiring>0&&<span className="use-soon-tag">🌿 {t("Uses food that's due soon","بيستخدم حاجة قربت تنتهي")}</span>}</div><button className="suggestion-open" onClick={()=>setSelectedRecipe(recipe)}>{t("Show me how","وريني الطريقة")}<ChevronRight size={17}/></button></article>)}</div>
            <div className="insight-grid">
              <div className="insight-card"><div className="insight-title"><Refrigerator size={19}/><strong>{t("Kitchen shortcuts","حاجات تسهّل عليك")}</strong></div>{leftovers.length>0?<p>🍱 {t(`${leftovers.reduce((sum,i)=>sum+i.quantity,0)} ready leftover serving(s). Dinner can be already done.`,"عندك وجبات باقية جاهزة، ممكن العشا يبقى محسوم.")}</p>:<p>{t("Cook once, save the second portion in the fridge, and make tomorrow easier.","اطبخ مرة وخلي الوجبة التانية في التلاجة لبكرة.")}</p>}{useSoon.length>0&&<p className="expiring-text">⏳ {t("Use soon:","استخدم قريب:")} {useSoon.map(x=>x.name).slice(0,3).join(" · ")}</p>}{pastDate.length>0&&<p className="expiring-text">⚠️ {t("Check date/label before using:","راجع تاريخ الصلاحية قبل الاستخدام:")} {pastDate.map(x=>x.name).slice(0,3).join(" · ")}</p>}<button className="text-button" onClick={()=>changeView("kitchen")}>{t("Open My Kitchen","افتح مطبخي")} <ChevronRight size={15}/></button></div>
              <div className="insight-card recovery-card"><div className="insight-title"><Heart size={19}/><strong>{t("No-guilt reset","ارجع ببساطة")}</strong></div><p>{t("Had a rough day or forgot the app? No streaks, no punishment, no need to restart your whole week.","يوم كان صعب أو نسيت الموقع؟ مفيش ستريك ضاع ولا عقاب ولا إعادة من أول الأسبوع.")}</p><button className="subtle-button" onClick={resetMode?()=>setResetMode(false):startReset}><RotateCcw size={15}/>{resetMode?t("Back to normal choices","ارجع للاختيارات العادية"):t("Give me an easy restart","خلينا نبدأ بداية سهلة")}</button></div>
            </div>
            <details className="reminder-settings"><summary><span><Bell size={18}/><strong>{t("Gentle food reminders","تذكير أكل من غير زن")}</strong></span><ChevronRight size={17}/></summary><div className="reminder-body"><p>{t("Optional, gentle daily notifications on Android. You can change or disable them any time.","إشعارات أندرويد يومية وهادية واختيارية. تقدر تعدّلها أو تقفلها في أي وقت.")}</p><label className="toggle-row"><span>{preferences.enabled?<Bell size={17}/>:<BellOff size={17}/>} {t("Turn reminders on","شغّل التذكيرات")}</span><input type="checkbox" checked={preferences.enabled} onChange={e=>setPreferences(v=>({...v,enabled:e.target.checked}))}/></label><div className="reminder-times">{preferences.times.map((time,i)=><label key={i}>{t(["First break","Afternoon","Evening"][i],["أول بريك","بعد الضهر","بالليل"][i])}<input type="time" value={time} onChange={e=>setPreferences(v=>({...v,times:v.times.map((x,j)=>j===i?e.target.value:x)}))}/></label>)}</div><button className="primary-button" disabled={!signedIn||saving} onClick={savePreferences}><Bell size={15}/>{t("Save my reminders","احفظ التذكيرات")}</button></div></details>
            <div className="bottom-tip">💚 {t("The goal is steady, satisfying meals and snacks. This is a helpful picker, not a restrictive diet or treatment.","الهدف وجبات وسناكس منتظمة ومشبعة. ده مساعد للاختيار، مش دايت قاسي ولا بديل للعلاج.")}</div>
          </section>}

          {view==="meals"&&<section className="content-section">
            <div className="section-heading"><div><span className="section-kicker">{t("THE FOOD LIBRARY","مكتبة الوجبات")}</span><h2>{t("What feels easy right now?","تحب تاكل إيه دلوقتي؟")}</h2></div><button className="subtle-button" disabled={saving||!signedIn} onClick={()=>savePlan({...easyWeek})}><Sparkles size={15}/>{t("Load easy week","حمّل أسبوع سهل")}</button></div>
            <div className="filter-row">{(["breakfast","snack","lunch","dinner","fast"] as Section[]).map((cat,i)=><button key={cat} className={"filter-pill "+(section===cat?"active":"")} onClick={()=>setSection(cat)}>{["🍳","🍌","🍚","🌙","⚡"][i]} {({breakfast:t("Breakfast","فطار"),snack:t("Snacks","سناكس"),lunch:t("Lunch","غدا"),dinner:t("Dinner & leftovers","عشا وبواقي"),fast:t("In a rush","وقت الزحمة")})[cat]}</button>)}</div>
            <div className="recipe-grid">{filteredRecipes.map(recipe=><article key={recipe.id} className="recipe-card"><div className="recipe-art"><span className="recipe-size">{recipe.batch?t("COOK ONCE · 2 MEALS","طبخة = وجبتين"):t("EASY PORTION","وجبة سهلة")}</span><span className="recipe-emoji">{recipe.emoji}</span></div><div className="recipe-body"><h3>{recipe.name[lang]}</h3><p>{recipe.sub[lang]}</p><div className="unit-pills">{Object.entries(recipe.units).slice(0,3).map(([k,v])=><span key={k}>{unitText(k,v)}</span>)}{recipe.leftover&&<span>{t("Already counted in your batch","متحسبة في الطبخة")}</span>}</div></div><div className="recipe-footer"><button className="text-button" onClick={()=>setSelectedRecipe(recipe)}>{t("See recipe","شوف الطريقة")} <ChevronRight size={13}/></button>{!recipe.leftover&&<div className="number-stepper"><button disabled={saving||!signedIn||!(counts[recipe.id]>0)} aria-label={"Remove "+recipe.name.en} onClick={()=>savePlan({...counts,[recipe.id]:Math.max(0,(counts[recipe.id]||0)-1)})}><Minus size={14}/></button><b>{counts[recipe.id]||0}</b><button disabled={saving||!signedIn} aria-label={"Add "+recipe.name.en} onClick={()=>savePlan({...counts,[recipe.id]:(counts[recipe.id]||0)+1})}><Plus size={14}/></button></div>}</div></article>)}</div>
            <div className="bottom-tip">💚 {t("Your portions are flexible. A busy day is not a failed day. Eat regularly and adjust to your hunger.","الكميات مرنة. اليوم الزحمة مش يوم باظ. خليك منتظم وزوّد حسب جوعك.")}</div>
          </section>}

          {view==="kitchen"&&<section className="content-section">
            <div className="kitchen-action-grid"><button className="action-tile featured" onClick={()=>{setReceiptOpen(true);setScanMode("input");}}><span className="action-tile-icon">📄</span><strong>{t("Import Lidl Kassenbon","استورد بون Lidl")}</strong><small>{t("Photo → review → save","صورة ← مراجعة ← حفظ")}</small><ChevronRight size={18}/></button><button className="action-tile manual" onClick={()=>document.querySelector(".quick-card:not(.backup-card)")?.scrollIntoView({behavior:"smooth",block:"start"})}><span className="action-tile-icon">✍️</span><strong>{t("Quick Add","إضافة يدوية سريعة")}</strong><small>{t("No weighing, no long forms","من غير وزن أو فورم طويل")}</small><ChevronRight size={18}/></button></div>
            <div className="quick-card backup-card"><div className="section-heading compact"><div><span className="section-kicker">YOUR DATA · YOUR PHONE</span><h2>{t("Backup & restore","نسخة احتياطية واسترجاع")}</h2></div></div><p className="help-text">{t("Your kitchen is saved offline in SQLite. Export a file to Google Drive when you want; importing replaces the current kitchen.","مطبخك محفوظ أوفلاين في SQLite. تقدر تحفظ نسخة في Google Drive وقت ما تحب؛ الاسترجاع بيستبدل المخزون الحالي.")}</p><div className="backup-actions"><button className="primary-button" onClick={()=>void shareBackup()}><ShieldCheck size={17}/>{t("Save backup","احفظ Backup")}</button><label className="backup-import-button">{t("Restore from file","رجّع من ملف")}<input type="file" accept="application/json,.json" onChange={e=>{const file=e.target.files?.[0];if(file)void importBackup(file);e.target.value="";}}/></label></div></div>
            <div className="quick-card"><div className="section-heading compact"><div><span className="section-kicker">{t("FAVORITES","المعتاد عندك")}</span><h2>{t("Add to my kitchen","ضيف للمخزون")}</h2></div></div><div className="favorite-row">{catalog.slice(0,10).map(p=><button key={p.code} className={"favorite-chip "+(quickCode===p.code?"selected":"")} onClick={()=>chooseQuick(p.code)}>{p.name}</button>)}<button className={"favorite-chip "+(quickCode==="custom"?"selected":"")} onClick={()=>{setQuickCode("custom");setQuickArea("pantry");setQuickQty(1);}}>＋ {t("Other","حاجة تانية")}</button></div><div className="quick-form"><div className="quick-product">{quickCode==="custom"?<input aria-label="Product name" value={quickName} onChange={e=>setQuickName(e.target.value)} placeholder={t("Product name","اسم المنتج")}/>:<span>{catalog.find(p=>p.code===quickCode)?.name}</span>}</div><label>{t("Quantity","الكمية")}<input aria-label="Quantity" type="number" min=".5" step=".5" value={quickQty} onChange={e=>setQuickQty(Number(e.target.value))}/></label><label>{t("Storage","المكان")}<select value={quickArea} onChange={e=>setQuickArea(e.target.value as Area)}><option value="fridge">🧊 Fridge</option><option value="freezer">❄️ Freezer</option><option value="pantry">📦 Pantry</option></select></label><button className="primary-button" disabled={saving||!signedIn} onClick={addQuick}>{saving?<Loader2 size={17} className="spin"/>:<Plus size={17}/>} {t("Save stock","احفظ الكمية")}</button></div><p className="help-text">{t("Pasta = 5 portions per 500g bag · Rice = 10 scoops per 1kg bag · Salmon = individual fillets.","كيس مكرونة 500 جم = 5 حصص · كيس رز 1 كجم = 10 مكاييل · اللاكس بالقطعة.")}</p></div>
            <div className="section-heading stock-title"><div><span className="section-kicker">{t("LIVE INVENTORY","المخزون الحالي")}</span><h2>{t("Everything in its place","كل حاجة في مكانها")}</h2></div><span className="small-count">{items.length} {t("items","منتج")}</span></div>
            {loading?<div className="empty-state"><Loader2 className="spin"/> {t("Loading your saved kitchen…","بحمّل مطبخك المحفوظ…")}</div>:items.length===0?<div className="empty-state"><Refrigerator size={39}/><strong>{t("Your kitchen starts here.","مطبخك بيبدأ من هنا.")}</strong><p>{t("Add a few favorites or import your next Lidl receipt. Your confirmed items will be stored permanently.","ضيف كام منتج أو استورد بون Lidl. اللي هتأكد عليه هيتحفظ بشكل دائم.")}</p></div>:<div className="inventory-grid">{(["fridge","freezer","pantry"] as Area[]).map(area=><div key={area} className="inventory-group"><div className="inventory-group-header"><span>{locationEmoji[area]} {area==="fridge"?t("Fridge","التلاجة"):area==="freezer"?t("Freezer","الفريزر"):t("Pantry","الدولاب")}</span><small>{areaCount(area)} {t("types","أنواع")}</small></div>{items.filter(x=>x.area===area).map(i=><div className={"inventory-item "+(i.quantity===0?"exhausted":"")} key={i.code}><div className="inventory-item-name"><strong>{i.name}</strong><small>{fmt(i.quantity)} {i.unit}{i.expiresAt?" · "+i.expiresAt:""}</small></div><div className="mini-stepper"><button aria-label={"Remove "+i.name} disabled={saving||!signedIn||i.quantity<=0} onClick={()=>adjust(i,-(i.quantity%1?0.5:1))}><Minus size={14}/></button><button aria-label={"Add "+i.name} disabled={saving||!signedIn} onClick={()=>adjust(i,1)}><Plus size={14}/></button></div></div>)}{areaCount(area)===0&&<p className="group-empty">{t("Nothing here yet","فاضي حاليًا")}</p>}</div>)}</div>}
            {!!imports.length&&<p className="receipt-history"><ShieldCheck size={15}/> {t("Last saved receipt: ","آخر بون محفوظ: ")}{new Date(imports[0].createdAt+"Z").toLocaleDateString(lang==="ar"?"ar-EG":"en-GB")} · {imports[0].productCount} {t("products","منتجات")}</p>}
            {items.length>0&&<details className="reminder-settings expiry-settings"><summary><span><Timer size={18}/><strong>{t("Best-before dates · optional","مواعيد الصلاحية · اختياري")}</strong></span><ChevronRight size={17}/></summary><div className="reminder-body"><p>{t("Add dates only when useful. Today will suggest meals using food that's due soon.","ضيف تاريخ الصلاحية لو حبيت. شاشة النهارده هترشّح وجبات تستخدم اللي قرب ينتهي.")}</p><div className="expiry-form"><select value={expiryCode} onChange={e=>{setExpiryCode(e.target.value);setExpiryDate(items.find(x=>x.code===e.target.value)?.expiresAt||"");}}><option value="">{t("Choose an item","اختار منتج")}</option>{items.filter(i=>i.quantity>0&&!i.code.startsWith("leftover:")).map(i=><option key={i.code} value={i.code}>{i.name}</option>)}</select><input aria-label="Best before date" type="date" value={expiryDate} onChange={e=>setExpiryDate(e.target.value)}/><button className="primary-button" disabled={!expiryCode||saving||!signedIn} onClick={async()=>{if(await doSave({action:"expiry",code:expiryCode,expiresAt:expiryDate||null},t("Best-before date saved ✓","تاريخ الصلاحية اتحفظ ✓"))){setExpiryCode("");setExpiryDate("");}}}>{t("Save date","احفظ التاريخ")}</button></div></div></details>}
          </section>}

          {view==="shopping"&&<section className="content-section">
            <div className="shopping-hero"><div><span className="section-kicker light">{t("SMART EINKAUFSLISTE · 7 DAYS","مشتريات ذكية · أسبوع واحد")}</span><h2>{t("Your Lidl week, sorted.","أسبوع Lidl من غير تكرار.")}</h2><p>{t("Needed for your selected meals, minus what you already have.","احتياجات وجباتك ناقص الموجود في مطبخك.")}</p></div><div className="shopping-hero-number"><strong>{missing.length}</strong><span>{t("to buy","ناقص")}</span></div></div>
            <div className="shopping-actions"><button className="subtle-button" onClick={copyShopping}><Copy size={15}/>{t("Copy list","انسخ الليسته")}</button><button className="subtle-button" onClick={()=>changeView("kitchen")}><Plus size={15}/>{t("Add existing stock","ضيف الموجود")}</button></div>
            {shopping.length===0?<div className="empty-state"><ShoppingBasket size={38}/><strong>{t("Pick some meals first.","اختار وجبات الأول.")}</strong><p>{t("Your weekly Lidl quantities will appear here.","الكميات اللي محتاج تشتريها هتظهر هنا.")}</p></div>:<div className="shopping-table"><div className="table-head"><span>{t("INGREDIENT","المنتج")}</span><span>{t("NEED","مطلوب")}</span><span>{t("IN STOCK","موجود")}</span><span>{t("TO BUY","ناقص")}</span></div>{shopping.map(p=><div className={"shop-row "+(p.buy===0?"in-stock":"")} key={p.code}><div className="shop-product"><span className="item-symbol">{p.code==="salmon"?"🐟":p.code==="pasta"?"🍝":p.code==="rice"?"🍚":p.code==="banana"?"🍌":"🛍️"}</span><div><strong>{p.name}</strong><small>{p.unit}</small></div></div><span>{fmt(p.needed)}</span><span>{fmt(p.owned)}</span><div className="buy-cell"><strong>{p.buy===0?"✓":fmt(p.buy)}</strong>{p.buy>0&&<button disabled={saving||!signedIn} onClick={()=>addBought(p)} title={t("Add bought amount to kitchen","ضيف الكمية للمخزون")}><Plus size={14}/></button>}</div></div>)}</div>}
            <p className="help-text">{t("These are planning estimates, not food limits. Buying the exact package size may leave extra stock for next week.","دي تقديرات للمشتريات مش حدود للأكل. ممكن يبقى عندك باقي من العبوة للأسبوع اللي بعده.")}</p>
          </section>}
        </div>
        <footer className="site-footer"><span>Made for Mena 🫶</span><span><ShieldCheck size={14}/> {t("Personal kitchen data · saved on this phone","بيانات مطبخك محفوظة على الموبايل")}</span></footer>
      </main>
    </div>
    <nav className="mobile-nav"><button onClick={()=>changeView("today")} className={view==="today"?"active":""}><House size={20}/>{t("Today","النهارده")}</button><button onClick={()=>changeView("meals")} className={view==="meals"?"active":""}><UtensilsCrossed size={20}/>{t("Meals","وجبات")}</button><button onClick={()=>changeView("kitchen")} className={view==="kitchen"?"active":""}><Refrigerator size={20}/>{t("Kitchen","مطبخي")}</button><button onClick={()=>changeView("shopping")} className={view==="shopping"?"active":""}><ShoppingBasket size={20}/>{t("Lidl","ليدل")}</button></nav>

    {selectedRecipe&&<div className="modal-backdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)setSelectedRecipe(null);}}><div className="dialog" role="dialog" aria-modal="true" aria-label={selectedRecipe.name[lang]}><button className="dialog-close" onClick={()=>setSelectedRecipe(null)} aria-label="Close"><X/></button><div className="dialog-emoji">{selectedRecipe.emoji}</div><span className="section-kicker">{selectedRecipe.batch?t("COOK ONCE · 2 MEALS","طبخة واحدة · وجبتين"):t("ONE PORTION","وجبة واحدة")}</span><h2>{selectedRecipe.name[lang]}</h2><p className="dialog-time"><Clock size={15}/> {selectedRecipe.minutes} {t("min approx.","دقيقة تقريبًا")}</p><div className="dialog-ingredients">{Object.entries(selectedRecipe.units).map(([k,v])=><span key={k}>{unitText(k,v)}</span>)}</div><ol>{selectedRecipe.steps[lang].map((s,i)=><li key={i}>{s}</li>)}</ol><div className="dialog-actions"><button className="subtle-button" onClick={()=>setSelectedRecipe(null)}>{t("Close","اقفل")}</button>{selectedRecipe.leftover?leftovers.length>0&&<button disabled={!signedIn||saving} className="primary-button" onClick={()=>eatLeftover(leftovers[0].code)}><Check size={16}/>{t("I ate one leftover · update stock","أكلت وجبة بواقي · حدّث المخزون")}</button>:<button disabled={!signedIn||saving} className="primary-button" onClick={()=>markCooked(selectedRecipe)}><Check size={16}/>{t("I cooked this · update stock","طبختها · حدّث المخزون")}</button>}</div></div></div>}

    {receiptOpen&&<div className="modal-backdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget&&!saving)setReceiptOpen(false);}}><div className="dialog receipt-dialog" role="dialog" aria-modal="true" aria-label="Import Lidl receipt"><button className="dialog-close" onClick={()=>setReceiptOpen(false)} aria-label="Close"><X/></button><span className="section-kicker">{t("LIDL KASSENBON IMPORT","استيراد بون Lidl")}</span><h2>{scanMode==="input"?t("Your receipt, in one place.","البون كله في مكان واحد."):t("Review before saving.","راجع قبل ما تحفظ.")}</h2><p className="dialog-description">{scanMode==="input"?t("Your receipt photo stays on your device while OCR reads it. We only save items you approve.","الصورة بتتقرأ على جهازك، وبنحفظ المنتجات اللي توافق عليها فقط."):t("Correct unclear names or package quantities, exclude household items, then save to your personal kitchen database.","عدّل الأسماء والكميات الغير واضحة، وشيل المنتجات المنزلية، وبعدها احفظ مخزونك.")}</p>
      {scanMode==="input"?<div className="receipt-input"><label className="file-drop"><FileImage size={34}/><strong>{t("Choose Lidl receipt photo","اختار صورة البون من Lidl")}</strong><small>JPG · PNG · WEBP</small><input type="file" accept="image/*" disabled={!!scanStatus} onChange={e=>{const file=e.target.files?.[0];if(file)void readReceipt(file);e.target.value="";}}/></label>{scanStatus&&<div className="ocr-progress"><Loader2 size={18} className="spin"/> {scanStatus}</div>}<div className="or-separator">{t("OR PASTE RECEIPT TEXT","أو الصق نص البون")}</div><textarea placeholder={t("Paste digital receipt text here…","الصق نص البون هنا…")} rows={5} value={receiptText} onChange={e=>setReceiptText(e.target.value)}/><button className="primary-button full" disabled={!receiptText.trim()||!!scanStatus} onClick={()=>importText(receiptText)}><ScanLine size={16}/>{t("Read product lines","استخرج المنتجات")}</button><p className="help-text">{t("Lidl Plus → Konto → Kassenbons → Download/Share. For PDFs, take a clear screenshot for this first version.","Lidl Plus ← Konto ← Kassenbons ← تنزيل أو مشاركة. لو PDF خد سكرينشوت واضح في النسخة الأولى.")}</p></div>:<><div className="review-summary"><span>{scanCandidates.length} {t("possible items","منتجات محتملة")}</span><span>{scanCandidates.filter(x=>x.include).length} {t("selected","محددة")}</span></div><div className="review-list">{scanCandidates.map(c=><div className={"review-item "+(!c.include?"excluded":"")} key={c.id}><label className="review-check"><input type="checkbox" checked={c.include} onChange={e=>updateCandidate(c.id,{include:e.target.checked})}/><span>{c.raw}</span></label><div className="review-edits"><input aria-label={"Name "+c.id} value={c.name} onChange={e=>updateCandidate(c.id,{name:e.target.value})}/><input aria-label={"Quantity "+c.id} type="number" min=".5" step=".5" value={c.quantity} onChange={e=>updateCandidate(c.id,{quantity:Number(e.target.value)})}/><span className="review-unit">{c.unit}</span><select value={c.area} onChange={e=>updateCandidate(c.id,{area:e.target.value as Area})}><option value="fridge">🧊</option><option value="freezer">❄️</option><option value="pantry">📦</option></select></div>{c.note&&<small className="review-note">⚠ {c.note}</small>}</div>)}{!scanCandidates.length&&<p className="empty-small">{t("No clear items. Try a sharper photo or Quick Add.","مفيش منتجات واضحة. جرّب صورة أوضح أو Quick Add.")}</p>}</div><div className="dialog-actions"><button className="subtle-button" onClick={()=>setScanMode("input")}>{t("Back","رجوع")}</button><button className="primary-button" disabled={saving||!signedIn||!scanCandidates.some(x=>x.include)} onClick={confirmReceipt}><Cloud size={16}/>{saving?t("Saving…","بيحفظ…"):t("Add selected to My Kitchen","احفظ المنتجات المحددة")}</button></div></>}
    </div></div>}
  </div>;
}
