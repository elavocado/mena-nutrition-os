import {Capacitor} from "@capacitor/core";
import recipes from "./recipes.json";

type Area="fridge"|"freezer"|"pantry";
type Food={code:string;name:string;quantity:number;unit:string;area:Area;expiresAt:string|null;updatedAt:string};
type History={recipeId:string;event:string;createdAt:string};
type Receipt={fingerprint:string;productCount:number;createdAt:string};
type State={items:Food[];counts:Record<string,number>;checked:Record<string,boolean>;imports:Receipt[];history:History[];preferences:{enabled:boolean;times:string[]}};

const starter:Record<string,number>={b_yogurt:2,b_overnight:1,b_eggs_cheese:2,b_egg_potato:2,s_banana:7,s_yogurt:3,s_eggs:4,m_salmon_rice:1,m_salmon_pasta:1,m_chicken_rice:1,m_chicken_pasta:1,m_tuna_rice:1,m_beef_wedges:1,m_chicken_wedges:1};
const initial=():State=>({items:[],counts:{...starter},checked:{},imports:[],history:[],preferences:{enabled:false,times:["12:30","16:30","19:30"]}});
const now=()=>new Date().toISOString().replace("T"," ").slice(0,19);

let connection:import("@capacitor-community/sqlite").SQLiteDBConnection|null=null;
let webDb:IDBDatabase|null=null;
let cache:State|null=null;
let queue=Promise.resolve();

async function initialize(){
  if(connection||webDb)return;
  if(Capacitor.isNativePlatform()){
    const {CapacitorSQLite,SQLiteConnection}=await import("@capacitor-community/sqlite");
    const sqlite=new SQLiteConnection(CapacitorSQLite);
    connection=await sqlite.createConnection("mena_nutrition",false,"no-encryption",1,false);
    await connection.open();
    await connection.execute("CREATE TABLE IF NOT EXISTS app_state (id INTEGER PRIMARY KEY, data TEXT NOT NULL)");
  }else{
    webDb=await new Promise<IDBDatabase>((resolve,reject)=>{
      const req=indexedDB.open("mena-nutrition-preview",1);
      req.onupgradeneeded=()=>req.result.createObjectStore("app");
      req.onsuccess=()=>resolve(req.result);
      req.onerror=()=>reject(req.error);
    });
  }
}

async function readRaw():Promise<string|null>{
  await initialize();
  if(connection){
    const result=await connection.query("SELECT data FROM app_state WHERE id=1");
    return result.values?.[0]?.data??null;
  }
  return new Promise((resolve,reject)=>{
    const req=webDb!.transaction("app","readonly").objectStore("app").get("state");
    req.onsuccess=()=>resolve(req.result??null);req.onerror=()=>reject(req.error);
  });
}
async function writeRaw(data:string){
  await initialize();
  if(connection){
    await connection.run("INSERT INTO app_state (id,data) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data",[data]);
  }else{
    await new Promise<void>((resolve,reject)=>{
      const tx=webDb!.transaction("app","readwrite");tx.objectStore("app").put(data,"state");
      tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);
    });
  }
}
async function load(){
  if(cache)return cache;
  const raw=await readRaw();
  if(raw){
    try{const parsed=JSON.parse(raw) as Partial<State>;cache={...initial(),...parsed,preferences:{...initial().preferences,...parsed.preferences}};return cache;}catch{/* corrupted storage reported through backup restore */}
  }
  cache=initial();return cache;
}

type Action={action:string;[key:string]:unknown};
const validArea=(value:unknown):value is Area=>value==="fridge"||value==="freezer"||value==="pantry";
const validCode=(code:string)=>/^[a-z0-9][a-z0-9_:-]{0,79}$/.test(code);
async function commit(state:State){await writeRaw(JSON.stringify(state));cache=state;}

async function execute(action:Action):Promise<Record<string,unknown>>{
  const prev=await load();
  const state:State=structuredClone(prev);
  switch(action.action){
    case "bulk":{
      if(!Array.isArray(action.items)||action.items.length>90)throw new Error("Invalid product list");
      const fingerprint=typeof action.fingerprint==="string"?action.fingerprint:"";
      if(fingerprint&&state.imports.some(r=>r.fingerprint===fingerprint))throw new Error("This receipt was already imported");
      for(const raw of action.items){
        const x=raw as Record<string,unknown>;
        const code=String(x.code||"");const quantity=Number(x.quantity);
        if(!validCode(code)||!validArea(x.area)||!Number.isFinite(quantity)||quantity<=0||quantity>5000)throw new Error("Invalid product details");
        const old=state.items.find(i=>i.code===code);
        if(old){old.quantity+=quantity;old.name=String(x.name||old.name);old.unit=String(x.unit||old.unit);old.area=x.area;old.updatedAt=now();}
        else state.items.push({code,name:String(x.name||code),quantity,unit:String(x.unit||"piece"),area:x.area,expiresAt:typeof x.expiresAt==="string"?x.expiresAt:null,updatedAt:now()});
      }
      if(fingerprint)state.imports.unshift({fingerprint,productCount:action.items.length,createdAt:now()});
      state.imports=state.imports.slice(0,10);break;
    }
    case "adjust":{
      const code=String(action.code||"");const delta=Number(action.delta);
      if(!validCode(code)||!Number.isFinite(delta))throw new Error("Invalid stock change");
      const item=state.items.find(i=>i.code===code);
      if(item){item.quantity=Math.max(0,item.quantity+delta);item.updatedAt=now();}
      break;
    }
    case "expiry":{
      const item=state.items.find(i=>i.code===action.code);
      if(item){item.expiresAt=typeof action.expiresAt==="string"?action.expiresAt:null;item.updatedAt=now();}
      break;
    }
    case "plan":{
      if(!action.counts||typeof action.counts!=="object")throw new Error("Invalid meal selection");
      state.counts=action.counts as Record<string,number>;
      state.checked=(action.checked||{}) as Record<string,boolean>;
      break;
    }
    case "preferences":{
      if(typeof action.enabled!=="boolean"||!Array.isArray(action.times)||action.times.length!==3||action.times.some(v=>typeof v!=="string"||!/^\d\d:\d\d$/.test(v)))throw new Error("Invalid reminder settings");
      state.preferences={enabled:action.enabled,times:action.times as string[]};break;
    }
    case "cook":{
      const recipe=recipes.find(r=>r.id===action.recipeId);
      if(!recipe||recipe.leftover)throw new Error("Unknown recipe");
      for(const [code,quantity] of Object.entries(recipe.units)){
        const item=state.items.find(i=>i.code===code);
        if(item){item.quantity=Math.max(0,item.quantity-quantity);item.updatedAt=now();}
      }
      if(recipe.batch){
        const code="leftover:"+recipe.id;const item=state.items.find(i=>i.code===code);
        if(item)item.quantity+=1;
        else state.items.push({code,name:recipe.name.en,quantity:1,unit:"meal",area:"fridge",expiresAt:null,updatedAt:now()});
      }
      state.history.unshift({recipeId:recipe.id,event:"cooked",createdAt:now()});break;
    }
    case "eat_leftover":{
      const item=state.items.find(i=>i.code===action.code&&i.code.startsWith("leftover:"));
      if(!item||item.quantity<1)throw new Error("No saved leftover serving");
      item.quantity-=1;item.updatedAt=now();
      state.history.unshift({recipeId:"d_leftovers",event:"leftover",createdAt:now()});break;
    }
    default:throw new Error("Unknown action");
  }
  state.history=state.history.slice(0,20);
  await commit(state);
  if(action.action==="preferences")await synchronizeNotifications(state.preferences);
  return {ok:true};
}

async function synchronizeNotifications(preferences:State["preferences"]){
  if(!Capacitor.isNativePlatform())return;
  const {LocalNotifications}=await import("@capacitor/local-notifications");
  await LocalNotifications.cancel({notifications:[{id:101},{id:102},{id:103}]});
  if(!preferences.enabled)return;
  let permission=await LocalNotifications.checkPermissions();
  if(permission.display!=="granted")permission=await LocalNotifications.requestPermissions();
  if(permission.display!=="granted")return;
  await LocalNotifications.schedule({notifications:preferences.times.map((time,i)=>{
    const [hour,minute]=time.split(":").map(Number);
    return {id:101+i,title:"Mena OS 💚",body:"A little food break? No pressure, just your next easy meal.",schedule:{on:{hour,minute},repeats:true}};
  })});
}

export async function requestOffline(body?:Action):Promise<any>{
  // Serialize writes so two fast taps cannot overwrite one another.
  if(body){
    const run=queue.then(()=>execute(body));
    queue=run.then(()=>undefined,()=>undefined);
    return run;
  }
  await queue;
  const s=await load();return structuredClone(s);
}

export async function exportBackup():Promise<string>{await queue;return JSON.stringify({version:1,exportedAt:new Date().toISOString(),data:await load()},null,2);}
export async function restoreBackup(json:string){
  const payload=JSON.parse(json) as {version:number;data:State};
  const s=payload.data;
  if(payload.version!==1||!s||!Array.isArray(s.items)||!s.preferences||typeof s.counts!=="object")throw new Error("This is not a Mena OS backup");
  await queue;await commit(s);await synchronizeNotifications(s.preferences);
}
