export type ScanCandidate = {
  id:string; raw:string; code:string; name:string; quantity:number; unit:string;
  area:"fridge"|"freezer"|"pantry"; include:boolean; note:string;
};

const patterns: Array<{pattern:RegExp;code:string;name:string;quantity:number;unit:string;area:ScanCandidate["area"];review?:string}> = [
  {pattern:/bodenhalt|^eier\b/,code:"eggs",name:"Eggs / Eier",quantity:1,unit:"egg",area:"fridge",review:"Check the pack size"},
  {pattern:/banan/,code:"banana",name:"Bananas / Bananen",quantity:1,unit:"banana",area:"pantry",review:"Receipt shows weight, confirm number of bananas"},
  {pattern:/lachs|salmon/,code:"salmon",name:"Salmon fillets / Lachs",quantity:1,unit:"fillet",area:"freezer",review:"Confirm number of individually packed fillets"},
  {pattern:/hah?nchen|h[uü]hn|hennenbrust|brustfilet/,code:"chicken",name:"Chicken portions",quantity:1,unit:"piece",area:"freezer",review:"Confirm number of portions"},
  {pattern:/rinderhack|hackfleisch|rindsn/,code:"beef",name:"Lean minced beef",quantity:1,unit:"400g pack",area:"fridge",review:"Confirm pack size"},
  {pattern:/thunfisch|tuna/,code:"tuna",name:"Tuna cans",quantity:1,unit:"can",area:"pantry"},
  {pattern:/linguine|spaghetti|penne|fusilli|spiralen|nudeln|macaroni|makkaroni/,code:"pasta",name:"Dry pasta / Nudeln",quantity:5,unit:"100g portion",area:"pantry",review:"Assumes a 500g bag; confirm size"},
  {pattern:/^reis\b|basmati|golden sun/,code:"rice",name:"Dry rice",quantity:10,unit:"100g scoop",area:"pantry",review:"Assumes a 1kg bag; confirm size"},
  {pattern:/buttergem|gem[uü]se.mix|tiefk[uü]hlgem/,code:"veg",name:"Frozen vegetables",quantity:1,unit:"300g carton",area:"freezer",review:"Confirm pack size and pea/butter tolerance"},
  {pattern:/wedges|kartoffel/,code:"potato",name:"Ready potatoes",quantity:1,unit:"750g bag",area:"freezer",review:"Confirm pack size"},
  {pattern:/joghurt|skyr/,code:"yogurt",name:"Yogurt",quantity:1,unit:"500g tub",area:"fridge",review:"Check lactose-free label and tub size"},
  {pattern:/k[aä]seaufschnitt|gouda|k[aä]se.scheiben/,code:"cheese",name:"Cheese slices",quantity:1,unit:"slice",area:"fridge",review:"Confirm number of slices; light does not mean lactose-free"},
  {pattern:/haferflocken|oats/,code:"oats",name:"Oats",quantity:1,unit:"tbsp",area:"pantry",review:"Enter number of tablespoons in the bag"},
];
const ignore = /^(lid[l1]|eur|mwst|tse|karte|kasse|gesamt|summe|rabat|preisvort|transaktion|serien|datum|vielen|erhaltene|punkte|telefon|kostenlose|adresse|filiale|am lachbach|brutto|netto)|\b(kg\s*x|eur\/kg|pay|rabatt|pfand|taschent[uü]ch\w*|m[uü]llbeutel\w*|windeln|babystrumpf\w*|servicenum|kassenbon)/i;
const roughProduct = /^(.{4,55}?)\s+\d+[,.]\d{2}(?:\s*[a-z])?$/i;
const clean = (s:string) => s.normalize("NFKD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
const keyFrom = (s:string) => "other:"+clean(s).replace(/[^a-z0-9]+/g,"_").replace(/^_|_$/g,"").slice(0,60);

export function parseReceipt(text:string):ScanCandidate[] {
  const output:ScanCandidate[]=[];
  for(const [index,source] of text.split(/\r?\n/).entries()){
    const raw=source.replace(/\s+/g," ").trim();
    if(raw.length<5||ignore.test(raw)||/^\d+[,.]\d+/.test(raw))continue;
    const normalized=clean(raw);
    const match=patterns.find(p=>p.pattern.test(normalized));
    if(match){
      const eggs=match.code==="eggs"&&/18er/.test(normalized)?18:match.code==="eggs"&&/10er/.test(normalized)?10:match.quantity;
      const review=match.code==="eggs"&&(eggs===18||eggs===10)?"":match.review||"";
      output.push({id:String(index),raw,code:match.code,name:match.name,quantity:eggs,unit:match.unit,area:match.area,include:!review,note:review});
      continue;
    }
    const candidate=raw.match(roughProduct);
    if(candidate&&/[a-zA-ZäöüÄÖÜ]{4}/.test(candidate[1])){
      const name=candidate[1].trim();
      output.push({id:String(index),raw,code:keyFrom(name),name,quantity:1,unit:"piece",area:"pantry",include:false,note:"Unknown item; confirm food, quantity and storage area"});
    }
  }
  return output.slice(0,90);
}
