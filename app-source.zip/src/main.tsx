import React from "react";
import {createRoot} from "react-dom/client";
import KitchenApp from "./kitchen-app";
import "./globals.css";

createRoot(document.getElementById("root")!).render(<React.StrictMode><KitchenApp signedIn={true} displayName="Mena" signInPath="/"/></React.StrictMode>);
