import type {CapacitorConfig} from "@capacitor/cli";

const config:CapacitorConfig={
  appId:"de.fox.menanutrition",
  appName:"Mena Nutrition OS",
  webDir:"dist",
  android:{allowMixedContent:false},
};
export default config;
